﻿
using CinemaxFinal.Models;
using Dapper;
using Microsoft.Data.SqlClient;
using System.Diagnostics;
using System.Reflection;
namespace CinemaxFinal.Models
{

    public class GenericRepository<TEntity> : IRepository<TEntity>
    {
        private readonly string connectionString;
        public GenericRepository(string connectionString)
        {
            this.connectionString = connectionString;
        }


        public void Add(TEntity entity)
        {
            // Get table name
            var tableName = typeof(TEntity).Name;

            // Get column names, excluding non-storable properties
            var properties = typeof(TEntity).GetProperties()
                                             .Where(p => p.Name != "Id"
                                                      && p.Name != "Image"
                                                      && p.Name != "ImageFile"
                                                      && p.Name != "VideoFile"
                                                      && !typeof(IFormFile).IsAssignableFrom(p.PropertyType));

            // Get column names as a comma-separated string
            var columnName = string.Join(",", properties.Select(p => p.Name));

            // Get parameter names as a comma-separated string
            var parameterNames = string.Join(",", properties.Select(p => "@" + p.Name));

            // Make query
            var query = $"INSERT INTO {tableName} ({columnName}) VALUES ({parameterNames})";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Execute query using Dapper
                connection.Execute(query, entity);
            }
        }


        public bool Delete(TEntity entity)
        {
            var tableName = typeof(TEntity).Name;
            var primaryKey = "Id";
            var query = $"DELETE FROM {tableName} WHERE {primaryKey} = @{primaryKey}";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                int rowsDeleted = connection.Execute(query, new { Id = entity.GetType().GetProperty(primaryKey).GetValue(entity) });
                return rowsDeleted > 0;
            }
        }



        public bool Update(TEntity entity)
        {
            var tableName = typeof(TEntity).Name;
            var primaryKey = "Id";

            var properties = typeof(TEntity).GetProperties()
                                             .Where(p => p.Name != primaryKey &&
                                                         p.Name != "ImageFile" &&
                                                         p.Name != "VideoFile" &&
                                                         !typeof(IFormFile).IsAssignableFrom(p.PropertyType));

            var setClause = string.Join(",", properties.Select(p => $"{p.Name}=@{p.Name}"));

            var query = $"UPDATE {tableName} SET {setClause} WHERE {primaryKey}=@{primaryKey}";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                int rowsAffected = connection.Execute(query, entity);
                return rowsAffected > 0;
            }
        }



        public IEnumerable<TEntity> GetAll()
        {
            var tableName = typeof(TEntity).Name;
            var query = $"SELECT * FROM {tableName}";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                return connection.Query<TEntity>(query);
            }
        }


        public TEntity SearchById(int id)
        {
            var tableName = typeof(TEntity).Name;
            var primaryKey = "Id";
            var query = $"SELECT * FROM {tableName} WHERE {primaryKey} = @Id";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                return connection.QueryFirstOrDefault<TEntity>(query, new { Id = id });
            }
        }








        //public void Add(TEntity entity)
        //{
        //    // Get table name
        //    var tableName = typeof(TEntity).Name;

        //    // Get column names, excluding non-storable properties
        //    var properties = typeof(TEntity).GetProperties()
        //                                    .Where(p => p.Name != "Id"
        //                                             && p.Name != "Image"
        //                                             && p.Name != "ImageFile"
        //                                             && p.Name != "VideoFile"
        //                                             && !typeof(IFormFile).IsAssignableFrom(p.PropertyType));

        //    // Get column names as a comma-separated string
        //    var columnName = string.Join(",", properties.Select(p => p.Name));

        //    // Make parameters
        //    var parameterNames = string.Join(",", properties.Select(p => "@" + p.Name));

        //    // Make query
        //    var query = $"INSERT INTO {tableName} ({columnName}) VALUES ({parameterNames})";

        //    using (var connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        var sqlCommand = new SqlCommand(query, connection);

        //        // Add parameters
        //        foreach (var property in properties)
        //        {
        //            var value = property.GetValue(entity);
        //            if (value is IFormFile formFile)
        //            {
        //                // Convert form file to byte array
        //                using (var memoryStream = new MemoryStream())
        //                {
        //                    formFile.CopyTo(memoryStream);
        //                    value = memoryStream.ToArray();
        //                }
        //            }

        //            sqlCommand.Parameters.AddWithValue("@" + property.Name, value ?? DBNull.Value);
        //        }

        //        sqlCommand.ExecuteNonQuery();
        //    }
        //}

        //public bool Delete(TEntity entity)
        //{
        //    // Get table name
        //    var tableName = typeof(TEntity).Name;
        //    var property = typeof(TEntity).GetProperty("Id");

        //    var query = $"DELETE FROM {tableName} WHERE Id = @Id";

        //    using (var connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        var sqlCommand = new SqlCommand(query, connection);
        //        sqlCommand.Parameters.AddWithValue("@" + property.Name, property.GetValue(entity));

        //        int rowsDeleted = sqlCommand.ExecuteNonQuery();
        //        if (rowsDeleted > 0)
        //        {
        //            return true;
        //        }
        //    }
        //    return false;
        //}
        //public bool Update(TEntity entity)
        //{
        //    if (entity == null)
        //    {
        //        throw new ArgumentNullException(nameof(entity));
        //    }

        //    var tableName = typeof(TEntity).Name;
        //    var primaryKey = "Id";

        //    // Get column names excluding the primary key
        //    var properties = typeof(TEntity).GetProperties()
        //                                    .Where(p => p.Name != primaryKey &&
        //                                                p.Name != "ImageFile" &&
        //                                                p.Name != "VideoFile" &&
        //                                                !typeof(IFormFile).IsAssignableFrom(p.PropertyType));

        //    // Create the SET clause
        //    var setClause = string.Join(",", properties.Select(p => $"{p.Name}=@{p.Name}"));

        //    // Construct the query
        //    var query = $"UPDATE {tableName} SET {setClause} WHERE {primaryKey}=@{primaryKey}";

        //    using (var connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        var sqlCommand = new SqlCommand(query, connection);

        //        // Add parameters for all properties except the primary key
        //        foreach (var property in properties)
        //        {
        //            var propertyName = property.Name;
        //            var propertyValue = property.GetValue(entity) ?? DBNull.Value;
        //            sqlCommand.Parameters.AddWithValue("@" + propertyName, propertyValue);
        //        }

        //        // Add parameter for the primary key
        //        var primaryKeyValue = typeof(TEntity).GetProperty(primaryKey).GetValue(entity);
        //        sqlCommand.Parameters.AddWithValue("@" + primaryKey, primaryKeyValue);

        //        // Debugging output
        //        Debug.WriteLine("SQL Command Text: " + sqlCommand.CommandText);
        //        foreach (SqlParameter param in sqlCommand.Parameters)
        //        {
        //            Debug.WriteLine($"Parameter: {param.ParameterName}, Value: {param.Value}");
        //        }

        //        // Execute the query
        //        int rowsAffected = sqlCommand.ExecuteNonQuery();
        //        return rowsAffected > 0;
        //    }
        //}

        //public IEnumerable<TEntity> GetAll()
        //{
        //    var tableName = typeof(TEntity).Name;
        //    var query = $"SELECT * FROM {tableName}";

        //    var entities = new List<TEntity>();

        //    using (var connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        var sqlCommand = new SqlCommand(query, connection);

        //        using (var reader = sqlCommand.ExecuteReader())
        //        {
        //            while (reader.Read())
        //            {
        //                var entity = Activator.CreateInstance<TEntity>();

        //                foreach (var property in typeof(TEntity).GetProperties().Where(p => p.Name != "ImageFile" && p.Name != "VideoFile"))// here exclude the properties agiant which there is no column in database
        //                {
        //                    var value = reader[property.Name];// == DBNull.Value ? null : reader[property.Name];
        //                    property.SetValue(entity, value);
        //                }

        //                entities.Add(entity);
        //            }
        //        }
        //    }
        //    return entities;
        //}
        //public TEntity SearchById(int id)
        //{
        //    var tableName = typeof(TEntity).Name;
        //    var query = $"SELECT * FROM {tableName} WHERE Id = @Id";

        //    using (var connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        var sqlCommand = new SqlCommand(query, connection);
        //        sqlCommand.Parameters.AddWithValue("@Id", id);

        //        using (var reader = sqlCommand.ExecuteReader())
        //        {
        //            if (reader.Read())
        //            {
        //                var entity = Activator.CreateInstance<TEntity>();

        //                foreach (var property in typeof(TEntity).GetProperties().Where(p => p.Name != "ImageFile" && p.Name != "VideoFile"))// here exclude the properties agiant which there is no column in database
        //                {
        //                    var value = reader[property.Name];
        //                    property.SetValue(entity, value);
        //                }

        //                return entity;
        //            }
        //        }
        //    }
        //    return default(TEntity);
        //}



    }
}

