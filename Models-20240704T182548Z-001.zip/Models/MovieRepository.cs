﻿using Azure.Core;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
namespace CinemaxFinal.Models
{
    public class MovieRepository : GenericRepository<Movie>
    {
        private string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=CinemaxDB;Integrated Security=True;";
        private SqlConnection connection;
        public MovieRepository() : base("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=CinemaxDB;Integrated Security=True;")
        {
            connection = new SqlConnection(connectionString);
        }


        public List<Movie> NewAndPopularDB()
        {
            string query = "SELECT TOP 10 * FROM MOVIE WHERE RELEASEYEAR = YEAR(GETDATE()) ORDER BY likes DESC";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                return connection.Query<Movie>(query).ToList();
            }
        }


        [HttpPost]
        public List<Movie> SearchDB(string searchTerm)
        {
            string query = "SELECT * FROM MOVIE WHERE NAME=@searchTerm";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                return connection.Query<Movie>(query, new { searchTerm }).ToList();
            }
        }
        public List<Movie> GetUserMovies(string userId)
        {
            string query = @"SELECT m.* FROM Movie m
                     JOIN UserList ul ON m.Id = ul.MovieId
                     WHERE ul.UserId = @userId";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                return connection.Query<Movie>(query, new { userId }).ToList();
            }
        }


        public void AddLikes(int movieId)
        {
            string query = "UPDATE Movie SET Likes = Likes + 1 WHERE Id = @movieId";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                connection.Execute(query, new { movieId });
            }
        }


        public void AddView(int movieId)
        {
            string query = "UPDATE Movie SET Views = Views + 1 WHERE Id = @movieId";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                connection.Execute(query, new { movieId });
            }
        }


        public void AddToList(string userId, int movieId)
        {
            string query = "INSERT INTO UserList (UserId, MovieId) VALUES (@userId, @movieId)";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                connection.Execute(query, new { userId, movieId });
            }
        }

        public bool MovieExistsInUserList(string userId, int movieId)
        {
            string query = "SELECT COUNT(*) FROM UserList WHERE userId = @userId AND movieId = @movieId";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                int count = connection.ExecuteScalar<int>(query, new { userId, movieId });
                return count > 0;
            }
        }
        public void RemoveFromList(string userId, int movieId)
        {
            string query = "Delete From UserList where userId=@userId and movieId=@movieId";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                connection.Execute(query, new { userId, movieId });
            }
        }


        public Movie GetMovieDetails(int movieId)
        {
            string query = @"SELECT Id, Name, Genre, Age, Quality, Description, ReleaseYear,Likes,Views
                     FROM Movie
                     WHERE Id = @movieId";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                return connection.QueryFirstOrDefault<Movie>(query, new { movieId });
            }
        }






        //public List<Movie> NewAndPopularDB()
        //{
        //    List<Movie> list = new List<Movie>();
        //    string query = "SELECT TOP 10 * FROM MOVIE WHERE RELEASEYEAR = YEAR(GETDATE()) ORDER BY likes DESC";
        //    SqlCommand selectCommand = new SqlCommand(query, connection);
        //    connection.Open();
        //    SqlDataReader reader = selectCommand.ExecuteReader();
        //    while (reader.Read())
        //    {
        //        Movie movie = new Movie
        //        {
        //            Name = reader["Name"].ToString(),
        //            Genre = reader["Genre"].ToString(),
        //            Description = reader["Description"].ToString(),
        //            ReleaseYear = Convert.ToInt32(reader["ReleaseYear"]),
        //            Age = reader["Age"].ToString(),
        //            Quality = reader["Quality"].ToString(),
        //            ImagePath = reader["ImagePath"].ToString(), // Assuming ImagePath is a column in your MOVIE table
        //            VideoPath = reader["VideoPath"].ToString() 
        //        };

        //        list.Add(movie);

        //    }
        //    connection.Close();


        //    return list;
        //}

        //[HttpPost]
        //public List<Movie> SearchDB(string searchTerm)
        //{
        //    List<Movie> list = new List<Movie>();
        //    string query = "SELECT * FROM MOVIE WHERE NAME=@searchTerm";

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {
        //            // Parameterize the search term to prevent SQL injection
        //            command.Parameters.AddWithValue("@searchTerm", searchTerm);

        //            connection.Open();
        //            using (SqlDataReader reader = command.ExecuteReader())
        //            {
        //                while (reader.Read())
        //                {
        //                    Movie movie = new Movie
        //                    {
        //                        Id = (int)reader["Id"],
        //                        Name = reader["Name"].ToString(),
        //                        Genre = reader["Genre"].ToString(),
        //                        Description = reader["Description"].ToString(),
        //                        ReleaseYear = (int)reader["ReleaseYear"],
        //                        Age = reader["Age"].ToString(),
        //                        Quality = reader["Quality"].ToString(),
        //                        ImagePath = reader["ImagePath"].ToString(), // Assuming ImagePath is a column in your MOVIE table
        //                        VideoPath = reader["VideoPath"].ToString()
        //                    };
        //                    list.Add(movie);
        //                }
        //            }
        //        }
        //    }

        //    return list;
        //}

        //public List<Movie> GetUserMovies(string userId)
        //{
        //    List<Movie> movies = new List<Movie>();
        //    string query = "SELECT m.* FROM Movie m " +
        //                   "JOIN UserList ul ON m.Id = ul.MovieId " +
        //                   "WHERE ul.UserId = @userId";

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {
        //            command.Parameters.AddWithValue("@userId", userId);
        //            connection.Open();
        //            using (SqlDataReader reader = command.ExecuteReader())
        //            {
        //                while (reader.Read())
        //                {
        //                    Movie movie = new Movie
        //                    {
        //                        Id = (int)reader["Id"],
        //                        Name = reader["Name"].ToString(),
        //                        Genre = reader["Genre"].ToString(),
        //                        Description = reader["Description"].ToString(),
        //                        ReleaseYear = (int)reader["ReleaseYear"],
        //                        Age = reader["Age"].ToString(),
        //                        Quality = reader["Quality"].ToString(),
        //                        ImagePath = reader["ImagePath"].ToString(), // Assuming ImagePath is a column in your MOVIE table
        //                        VideoPath = reader["VideoPath"].ToString()
        //                    };
        //                    movies.Add(movie);
        //                }
        //            }
        //        }
        //    }

        //    return movies;
        //}



        //public void AddLikes(int movieId)
        //{
        //    string query = "UPDATE Movie SET Likes = Likes + 1 WHERE Id = @movieId";

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {
        //            command.Parameters.AddWithValue("@movieId", movieId);
        //            connection.Open();
        //            command.ExecuteNonQuery();
        //        }
        //    }
        //}

        //public void AddView(int movieId)
        //{
        //    string query = "UPDATE Movie SET Views = Views + 1 WHERE Id = @movieId";

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {
        //            command.Parameters.AddWithValue("@movieId", movieId);
        //            connection.Open();
        //            command.ExecuteNonQuery();
        //        }
        //    }
        //}

        //public void AddToList(string userId, int movieId)
        //{
        //    string query = "INSERT INTO UserList (UserId, MovieId) VALUES (@userId, @movieId)";

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {
        //            command.Parameters.AddWithValue("@userId", userId);
        //            command.Parameters.AddWithValue("@movieId", movieId);
        //            connection.Open();
        //            command.ExecuteNonQuery();
        //        }
        //    }
        //}

        //public Movie GetMovieDetails(int movieId)
        //{
        //    Movie movie=null; // Initialize movie to null

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        string query = "SELECT Id, Name, Genre, Age, Quality, Description, ReleaseYear " +
        //                       "FROM Movie " +
        //                       "WHERE Id = @movieId";

        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {
        //            command.Parameters.AddWithValue("@movieId", movieId);
        //            connection.Open();

        //            using (SqlDataReader reader = command.ExecuteReader())
        //            {
        //                if (reader.Read())
        //                {
        //                    movie = new Movie(); // Initialize movie object if a record is found
        //                    movie.Id = (int)reader["Id"];
        //                    movie.Name = reader["Name"].ToString();
        //                    movie.Genre = reader["Genre"].ToString();
        //                    movie.Age = reader["Age"].ToString();
        //                    movie.Quality = reader["Quality"].ToString();
        //                    movie.Description = reader["Description"].ToString();
        //                    movie.ReleaseYear = (int)reader["ReleaseYear"];
        //                }
        //            }
        //        }
        //    }

        //    return movie;
        //}

    }

}
