﻿namespace CinemaxFinal.Models
{
    public class UserList
    {
        //public int Id { get; set; }

        public string UserId {  get; set; }
        public int MovieId { get; set; }
        //public bool Watched { get; set; }

        //public string UserName {  get; set; }
    }
}
