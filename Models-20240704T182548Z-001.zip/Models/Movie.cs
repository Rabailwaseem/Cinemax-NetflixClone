﻿using System.Composition.Convention;

namespace CinemaxFinal.Models
{
    public class Movie
    {
        public int Id { get; set; }
        public string Name { get; set; } 
        public string Genre { get; set; }
        public int ReleaseYear { get; set; }
        public string Description { get; set; }
        public string Age { get; set; }
        public string Quality { get; set; }

        public string ImagePath { get; set; }
        public string VideoPath { get; set; }

        public IFormFile ImageFile {get; set; }
        public IFormFile VideoFile { get; set; }

        public int Likes { get; set; } 
        public int Views { get; set; } 

       



    }

}
