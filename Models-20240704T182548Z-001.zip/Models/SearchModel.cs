﻿namespace CinemaxFinal.Models
{
    public class SearchModel
    {
        public string SearchTerm { get; set; } = "Movie1";
    }
}
