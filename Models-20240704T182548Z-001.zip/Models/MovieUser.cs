﻿namespace CinemaxFinal.Models
{
    public class MovieUser
    {
        public UserList MyUser { get; set; }
        public List<Movie> movie { get; set; }
        public MovieUser(UserList u,List<Movie> list)
        {
            MyUser = u;
            movie=list;
        }
       
    }
}
