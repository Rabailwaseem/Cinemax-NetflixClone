﻿//using Microsoft.Data.SqlClient;
//using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

//namespace CinemaxFinal.Models
//{
//    public class UserListRepository
//    {

//        private readonly string connectionString= "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=CinemaxDB;Integrated Security=True;";

//        public void AddMovieToList(int userId, int movieId)
//        {
//            using (SqlConnection connection = new SqlConnection(connectionString))
//            {
//                connection.Open();
//                string query = "INSERT INTO UserList (UserId, MovieId, Watched) VALUES (@UserId, @MovieId, 0)";
//                using (SqlCommand command = new SqlCommand(query, connection))
//                {
//                    command.Parameters.AddWithValue("@UserId", userId);
//                    command.Parameters.AddWithValue("@MovieId", movieId);
//                    command.ExecuteNonQuery();
//                }
//            }
//        }

//        public void RemoveMovieFromList(int userId, int movieId)
//        {
//            using (SqlConnection connection = new SqlConnection(connectionString))
//            {
//                connection.Open();
//                string query = "DELETE FROM UserList WHERE UserId = @UserId AND MovieId = @MovieId";
//                using (SqlCommand command = new SqlCommand(query, connection))
//                {
//                    command.Parameters.AddWithValue("@UserId", userId);
//                    command.Parameters.AddWithValue("@MovieId", movieId);
//                    command.ExecuteNonQuery();
//                }
//            }
//        }


//        public List<Movie> MyListDB()
//        {
//            List<Movie> list = new List<Movie>();
//            string query = "SELECT * FROM MOVIES m JOIN USERLIST u ON m.Id = u.MovieId";
//            using (SqlConnection connection = new SqlConnection(connectionString))
//            {
//                using (SqlCommand selectCommand = new SqlCommand(query, connection))
//                {
//                    connection.Open();
                  
//                    using (SqlDataReader reader = selectCommand.ExecuteReader())
//                    {
                       
//                        while (reader.Read())
//                        {
//                            Movie movie = new Movie
//                            {
//                                Name = reader["Name"].ToString(),
//                                Genre = reader["Genre"].ToString(),
//                                Description = reader["Description"].ToString(),
//                                ReleaseYear = Convert.ToInt32(reader["ReleaseYear"]),
//                                Age = reader["Age"].ToString(),
//                                Quality = reader["Quality"].ToString()
//                                // Assuming other properties of Movie class are similar to column names in the database
//                            };

//                            list.Add(movie);
//                        }
//                    }
//                    connection.Close();
//                }
//            }

//            return list;
//        }


//    }
//}
